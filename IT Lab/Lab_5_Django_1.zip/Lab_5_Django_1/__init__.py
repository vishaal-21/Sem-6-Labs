"""
Package for Lab_5_Django_1.
"""
