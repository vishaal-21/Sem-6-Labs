"""
Definition of urls for Lab_5_Django_1.
"""

from datetime import datetime
from django.urls import path
from django.contrib import admin
from django.contrib.auth.views import LoginView, LogoutView
from django.urls import include,path
# from app import forms, views
# from TwoSum import views
from Webform import views
from Empform import views


urlpatterns = [
    path('Empform/',include('Empform.urls')),
    path('',include('Webform.urls'))
]
